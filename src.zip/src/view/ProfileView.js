import React, { Component } from 'react';
import { Form, Input, Button, Avatar } from 'antd';
import { SmileOutlined  } from '@ant-design/icons';

class Profile extends Component {
  formRef = React.createRef();

  onFinish = (values) => {
    console.log(values);
  };

  onCancel = () => {
    this.formRef.current.resetFields();
  };

  render() {
    return (
      <Form
        ref={this.formRef}
        layout="vertical"
        onFinish={this.onFinish}
        initialValues={{
          name: '',
          surname: '',
          twitter: '',
          avatar: '',
        }}
      >
        <Form.Item label="Name" name="name">
          <Input />
        </Form.Item>
        <Form.Item label="Surname" name="surname">
          <Input />
        </Form.Item>
        <Form.Item label="Twitter" name="twitter">
          <Input prefix="@"/>
        </Form.Item>
        <Form.Item label="Avatar" name="avatar">
          <Avatar size={64} icon={<SmileOutlined />} />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
          <Button style={{ marginLeft: 8 }} onClick={this.onCancel}>
            Cancel
          </Button>
        </Form.Item>
      </Form>
    );
  }
}

export default Profile;