import React from 'react';
import './App.css';
import BasicRoute from "./Router";

class App extends React.Component {


  render() {
    return (
        <BasicRoute/>
    );
  }
}


export default App;
